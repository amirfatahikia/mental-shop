module.exports = {
  plugins: {
    '@tailwindcss/postcss': {}, // تغییر از tailwindcss به @tailwindcss/postcss
    autoprefixer: {},
  },
}