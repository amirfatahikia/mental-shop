var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/payment/request/route.js")
R.c("server/chunks/[root-of-the-server]__dc3ae502._.js")
R.c("server/chunks/[root-of-the-server]__71e0e3b9._.js")
R.c("server/chunks/_next-internal_server_app_api_payment_request_route_actions_4d073186.js")
R.m(34409)
module.exports=R.m(34409).exports
