var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/user-profile/route.js")
R.c("server/chunks/[root-of-the-server]__2a263371._.js")
R.c("server/chunks/[root-of-the-server]__71e0e3b9._.js")
R.c("server/chunks/_next-internal_server_app_api_user-profile_route_actions_4f8d7c44.js")
R.m(69241)
module.exports=R.m(69241).exports
