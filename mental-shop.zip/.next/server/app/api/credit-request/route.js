var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/credit-request/route.js")
R.c("server/chunks/[root-of-the-server]__5732d924._.js")
R.c("server/chunks/[root-of-the-server]__71e0e3b9._.js")
R.c("server/chunks/_next-internal_server_app_api_credit-request_route_actions_7d90dd11.js")
R.m(2937)
module.exports=R.m(2937).exports
