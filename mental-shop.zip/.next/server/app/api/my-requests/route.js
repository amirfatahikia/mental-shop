var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/my-requests/route.js")
R.c("server/chunks/[root-of-the-server]__b967d010._.js")
R.c("server/chunks/[root-of-the-server]__71e0e3b9._.js")
R.c("server/chunks/_next-internal_server_app_api_my-requests_route_actions_2c526b59.js")
R.m(44623)
module.exports=R.m(44623).exports
