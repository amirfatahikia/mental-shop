globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/0acb211be0a29b2f.js",
    "static/chunks/236f7e5abd6f09ff.js",
    "static/chunks/cc759f7c2413b7ff.js",
    "static/chunks/75a6d27479ddbcf1.js",
    "static/chunks/turbopack-44997a29e0cbdddb.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];