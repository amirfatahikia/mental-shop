module.exports=[71212,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_user-profile_route_actions_4f8d7c44.js.map