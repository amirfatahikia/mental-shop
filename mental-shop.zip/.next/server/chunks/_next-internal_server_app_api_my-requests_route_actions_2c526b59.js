module.exports=[13015,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_my-requests_route_actions_2c526b59.js.map