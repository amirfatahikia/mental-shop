module.exports=[32053,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_category_%5Bslug%5D_page_actions_6f1982fe.js.map