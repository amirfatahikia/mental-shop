module.exports=[75829,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_order-success_page_actions_9d12917d.js.map