module.exports=[84714,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_installments_page_actions_33ead5d6.js.map