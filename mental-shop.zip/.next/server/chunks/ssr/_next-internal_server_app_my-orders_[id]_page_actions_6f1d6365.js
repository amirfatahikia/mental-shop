module.exports=[49095,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_my-orders_%5Bid%5D_page_actions_6f1d6365.js.map