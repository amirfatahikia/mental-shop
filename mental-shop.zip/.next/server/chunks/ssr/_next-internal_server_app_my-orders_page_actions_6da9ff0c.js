module.exports=[14667,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_my-orders_page_actions_6da9ff0c.js.map