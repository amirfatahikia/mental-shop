module.exports=[72185,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_panel_page_actions_37c8d8a2.js.map