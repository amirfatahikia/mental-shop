module.exports=[5895,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_about_page_actions_6fff35e4.js.map