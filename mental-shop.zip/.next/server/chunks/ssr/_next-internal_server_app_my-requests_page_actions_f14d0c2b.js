module.exports=[23076,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_my-requests_page_actions_f14d0c2b.js.map